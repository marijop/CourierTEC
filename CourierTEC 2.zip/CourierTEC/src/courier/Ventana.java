/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package courier;

/**
 *
 * @author giank
 */
import courier.tipoPaquete;
import courier.tipoVentana;
public class Ventana {
    int tiempo;
    tipoPaquete tipoP;
    tipoVentana tipoV;
    tipoEstado estado;
    int cantAtendidos;
    
     public Ventana(){
         
     }
     //Constructor de ventan de entregas
     public Ventana(tipoPaquete tipoPaq,tipoVentana tipoVent,tipoEstado estado){
         this.tipoP=tipoPaq;
         this.tipoV=tipoVent;
         this.estado=estado;
         this.cantAtendidos=0;
     }
     public Ventana(tipoPaquete tipoPaq,tipoVentana tipoVent,tipoEstado estado,int time){
         this.tiempo=time;
         this.tipoP=tipoPaq;
         this.tipoV=tipoVent;
         this.estado=estado;
         this.cantAtendidos=0;
     }
     
     public int getTiempo(){
         return this.tiempo;
     }
     public void setTiempo(int T){
         this.tiempo=T;
     }
     public tipoPaquete gettipoP(){
         return this.tipoP;
     }
     public void setTipoP(tipoPaquete tp){
         this.tipoP=tp;
     }
     public tipoVentana getTipoV(){
         return this.tipoV;
     }
     public void settipoV(tipoVentana tv){
         this.tipoV=tv;
     }
     public tipoEstado getEstado(){
         return this.estado;
     }
     public void setEstado (tipoEstado state){
         this.estado=state;
     }
     public int getcantAtendidos(){
         return this.cantAtendidos;
     }
     public void setcantAtendidos(int cant){
         this.cantAtendidos=cant;
     }
    
    
}
