/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Estructuras;

/**
 *
 * @author giank
 */
public class ArbolB<T> {
    private Nodos<T> raiz;
    public ArbolB(T element){
        this.raiz=new Nodos<>(element);
        
    }
    public ArbolB(Nodos<T> r){
        this.raiz=r;
    }
    public Nodos<T> getRaiz(){
        return this.raiz;
    }
    public void setRaiz(Nodos<T> R){
        this.raiz=R;
    }
}
