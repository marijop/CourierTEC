/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Estructuras;

/**
 *
 * @author giank
 */
import courier.Cliente;
import courier.tipoPaquete;
import courier.TipoCliente;
public class prueba {

    
    public static void main(String[] args) {
        Colas <Cliente> nueva=new Colas<>();
     
        Cliente nuevo1=new Cliente("Ulyse Jimenez","Giank99-@gmail.com",TipoCliente.Embarazada,tipoPaquete.percedero);
        Cliente nuevo2=new Cliente("o Jimenez","Giank99-@gmail.com",TipoCliente.MayorE,tipoPaquete.percedero);
        Cliente nuevo3=new Cliente("Chorizo Jimenez","Giank99-@gmail.com",TipoCliente.Regular,tipoPaquete.percedero);
        Cliente nuevo4=new Cliente("Fernado Jimenez","Giank99-@gmail.com",TipoCliente.Embarazada,tipoPaquete.percedero);
        Cliente nuevo5=new Cliente("Alexander Jimenez","Giank99-@gmail.com",TipoCliente.Desc,tipoPaquete.noPercedero);
        Cliente nuevo6=new Cliente("Giancarlo Jimenez","Giank99-@gmail.com",TipoCliente.Regular,tipoPaquete.noPercedero);
        Cliente nuevo7=new Cliente("Carlos Jimenez","Giank99-@gmail.com",TipoCliente.Embarazada,tipoPaquete.percedero);
        nueva.enqueque(nuevo1);
        nueva.enqueque(nuevo2);
        nueva.enqueque(nuevo3);
        nueva.enqueque(nuevo4);
        nueva.enqueque(nuevo5);
        nueva.enqueque(nuevo6);
        nueva.enqueque(nuevo7);
        nueva.dequeue();
        System.out.print(nueva.getSize());
        
    }
    
}
